package snakes_ui;

import snakes.Coordinate;
import snakes.SnakeGame;

import java.awt.*;
import java.awt.image.BufferStrategy;

public class SnakeCanvas extends Canvas {
    private static final int CELL_SIZE = 40;
    private static final int PAD = 2;
    private static final int SMALLER_PAD = 5;
    private static final int SMALL_PAD = 12;
    private static final Color color0 = Color.red;
    private static final Color color1 = Color.blue;
    private static final Color bodyColor = Color.green;
    private static final Color backgroundColor = Color.black;
    private static final Color borderColor = new Color(22, 50, 76);
    private static final Color appleColor = Color.blue;

    Dimension renderSize;
    BufferStrategy bufferStrategy;
    private SnakeGame game;

    /* construct snake canvas */
    public SnakeCanvas(SnakeGame game) {
        this.game = game;

        renderSize = new Dimension((game.mazeSize.x + 2) * CELL_SIZE, (game.mazeSize.y + 2) * CELL_SIZE);
    }

    /* fill cell with some padding */
    private void fillCellWithPad(Graphics2D g, Coordinate cell, Color color, int pad) {
        g.setColor(color);
        g.fillRect((cell.x + 1) * CELL_SIZE + pad, (cell.y + 1) * CELL_SIZE + pad, CELL_SIZE - 2 * pad, CELL_SIZE - 2 * pad);
    }

    /* fill cell */
    private void fillCell(Graphics2D g, Coordinate cell, Color color) {
        fillCellWithPad(g, cell, color, PAD);
    }

    /* fill smaller cell */
    private void fillSmallerCell(Graphics2D g, Coordinate cell, Color color) {
        fillCellWithPad(g, cell, color, SMALLER_PAD);
    }

    /* fill small cell */
    private void fillSmallCell(Graphics2D g, Coordinate cell, Color color) {
        fillCellWithPad(g, cell, color, SMALL_PAD);
    }

    /* render the game */
    private void render(Graphics2D g){
        g.setColor(borderColor);
        g.fillRect(0,0, renderSize.width, renderSize.height);
        g.setColor(backgroundColor);
        g.fillRect(CELL_SIZE, CELL_SIZE, renderSize.width - 2 * CELL_SIZE, renderSize.height - 2 * CELL_SIZE);

        fillSmallerCell(g, game.appleCoordinate, appleColor);

        var it = game.snake0.body.stream().iterator();
        while (it.hasNext()) {
            var bp = it.next();
            fillCell(g, bp, color0);
            fillSmallerCell(g, bp, bodyColor);
        }

        it = game.snake1.body.stream().iterator();
        while (it.hasNext()) {
            var bp = it.next();
            fillCell(g, bp, color1);
            fillSmallerCell(g, bp, bodyColor);
        }

        fillSmallCell(g, game.snake0.getHead(), color0);
        fillSmallCell(g, game.snake1.getHead(), color1);

    }

    /* repaint the control */
    @Override
    public void paint(Graphics g) {
        Graphics2D gg = (Graphics2D) g; //bufferStrategy.getDrawGraphics();
        gg.clearRect(0, 0, renderSize.width, renderSize.height);
        render(gg);

        //bufferStrategy.show();
    }
}
