package snakes;

public class Coordinate implements Comparable {
    int row, column;

    // initializes the fields
    public Coordinate(int row, int column) {
        this.row = row;
        this.column = column;
    }

    // compares what coordinate is preferable to take
    public int compareTo(Object o) {
        int     value_coord1 = 1,
                value_coord2 = 1;

        Coordinate anotherCoordinate = (Coordinate)o;

        if ( !isValid() )
            value_coord1 = 1;
        else if ( isApple() )
            value_coord1 = 4;
        else if ( isNoCollision() )
            value_coord1 = 3;
        else if ( isHeadToHeadCollision() )
            value_coord1 = 2;

        if ( !anotherCoordinate.isValid() )
            value_coord2 = 1;
        else if ( anotherCoordinate.isApple() )
            value_coord2 = 4;
        else if ( anotherCoordinate.isNoCollision() )
            value_coord2 = 3;
        else if ( anotherCoordinate.isHeadToHeadCollision() )
            value_coord2 = 2;

        if ( value_coord1 > value_coord2 )
            return 1;
        if ( value_coord1 == value_coord2 )
            return 0;
       else
            return -1;
    }

    // checks if the coordinate is in the maze
    private boolean isValid() {
        if (    (0 <= row && row < Snakes.MAZE_ROW_NUM) &&
                (0 <= column && column < Snakes.MAZE_COLUMN_NUM) )
            return true;
        return false;
    }

    // checks if there is an apple in the coordinate
    private boolean isApple() {
        if ( Snakes.maze[row][column] == 8 )
            return true;
        return false;
    }

    //checks is there is no snakes here
    private boolean isNoCollision() {
        if (    !Snakes.snake0.belongsToSnake(row,column) &&
                !Snakes.snake1.belongsToSnake(row,column)
        )
            return true;
        return false;
    }

    // check is there is a head of another snake here
    private boolean isHeadToHeadCollision() {
        if (    ( row == Snakes.snake0.getHead().row && column == Snakes.snake0.getHead().column ) ||
                ( row == Snakes.snake1.getHead().row && column == Snakes.snake1.getHead().column )
        )
            return true;
        return false;
    }

    /*private boolean isLoserCollision() {
        if ( !isApple() && !isNoCollision() && !isHeadToHeadCollision() )
            return true;
        return false;
    }*/

}
