package snakes;

import java.util.ArrayList;

public class Snake {
    boolean alive;
    //boolean collision = false;
    boolean headCollision = false;
    ArrayList<Position> positions;

    /**
     * Constructor
     *
     * @param row    Row of the head
     * @param column Column of the head
     */

    //constructor of the snake ( initializes the variables and the arraylist )
    public Snake(int row, int column, int size)
    {
        alive = true;
        positions = new ArrayList<Position>();
        for ( int i = 0 ; i < size ; i++ )
            positions.add(new Position(row, column-i));
    }

    // returns the position of the head
    public Position getHead() {
        return positions.get(0);
    }

    // makes the snake move to the north
    public void MoveN()
    {
        if ( Snakes.maze[getHead().row-1][getHead().column] == 8 ) {
            Grow(getHead().row-1,getHead().column);
            return;
        }
        Position tempPos1, tempPos2;
        tempPos1 = positions.get(0);
        positions.set(0,new Position(tempPos1.row-1,tempPos1.column));
        for ( int i = 1 ; i < positions.size() ; i++ ) {
            tempPos2 = positions.get(i);
            positions.set(i,tempPos1);
            tempPos1 = tempPos2;
        }
    }

    // makes the snake move to the east
    public void MoveE()
    {
        if ( Snakes.maze[getHead().row][getHead().column+1] == 8 ) {
            Grow(getHead().row,getHead().column+1);
            return;
        }
        Position tempPos1, tempPos2;
        tempPos1 = positions.get(0);
        positions.set(0,new Position(tempPos1.row,tempPos1.column+1));
        for ( int i = 1 ; i < positions.size() ; i++ ) {
            tempPos2 = positions.get(i);
            positions.set(i,tempPos1);
            tempPos1 = tempPos2;
        }
    }

    // makes the snake move to the south
    public void MoveS()
    {
        if ( Snakes.maze[getHead().row+1][getHead().column] == 8 ) {
            Grow(getHead().row+1,getHead().column);
            return;
        }
        Position tempPos1, tempPos2;
        tempPos1 = positions.get(0);
        positions.set(0,new Position(tempPos1.row+1,tempPos1.column));
        for ( int i = 1 ; i < positions.size() ; i++ ) {
            tempPos2 = positions.get(i);
            positions.set(i,tempPos1);
            tempPos1 = tempPos2;
        }
    }

    // makes the snake move to the west
    public void MoveW()
    {
        if ( Snakes.maze[getHead().row][getHead().column-1] == 8 ) {
            Grow(getHead().row,getHead().column-1);
            return;
        }
        Position tempPos1, tempPos2;
        tempPos1 = positions.get(0);
        positions.set(0,new Position(tempPos1.row,tempPos1.column-1));
        for ( int i = 1 ; i < positions.size() ; i++ ) {
            tempPos2 = positions.get(i);
            positions.set(i,tempPos1);
            tempPos1 = tempPos2;
        }
    }

    //checks if there is a snake in the position
    public boolean belongsToSnake(int row, int column) {
        boolean ans = false;
        for ( int i = 0 ; i < positions.size(); i++ ) {
            if ( positions.get(i).row == row && positions.get(i).column == column )
                ans = true;
        }
        return ans;
    }
    public boolean belongsToSnake(int row, int column, boolean checkTail) {
        boolean ans = false;
        for ( int i = 0 ; i < positions.size() - (checkTail ? 1 : 0) ; i++ ) {
            if ( positions.get(i).row == row && positions.get(i).column == column )
                ans = true;
        }
        return ans;
    }

    //generates an appropriate random move
    public String nextMove() {
        String move = null;
        int numOfMove;

        while ( move == null ) {
            numOfMove = (int) (4 * Math.random());
            switch (numOfMove) {
                case 0:
                    move = "N";
                    if ( getHead().row - 1 == positions.get(1).row && getHead().column == positions.get(1).column )
                        move = null;
                    if ( getHead().row - 1 < 0 )
                        move = null;
                    break;
                case 1:
                    move = "E";
                    if ( getHead().row == positions.get(1).row && getHead().column + 1 == positions.get(1).column )
                        move = null;
                    if ( getHead().column + 1 >= Snakes.MAZE_COLUMN_NUM )
                        move = null;
                    break;
                case 2:
                    move = "S";
                    if ( getHead().row + 1 == positions.get(1).row && getHead().column == positions.get(1).column )
                        move = null;
                    if ( getHead().row + 1 >= Snakes.MAZE_ROW_NUM )
                        move = null;
                    break;
                case 3:
                    move = "W";
                    if ( getHead().row == positions.get(1).row && getHead().column - 1 == positions.get(1).column )
                        move = null;
                    if ( getHead().column - 1 < 0 )
                        move = null;
                    break;
            }
        }

        return move;
    }

    //makes the snake grow
    public void Grow(int row, int column)
    {
        positions.add(0,new Position(row, column));
        Snakes.maze[row][column] = 0;
    }
}
