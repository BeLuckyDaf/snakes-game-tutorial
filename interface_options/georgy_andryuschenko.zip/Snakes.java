// g.andryushchenko@innopolis.university

package snakes;

import java.awt.*;

public class Snakes {

    public static final int     MAZE_ROW_NUM            = 8,
                                MAZE_COLUMN_NUM         = 8,

                                FIRST_SNAKE_ROW         = 1,
                                FIRST_SNAKE_COLUMN      = 4,
                                FIRST_SNAKE_SIZE        = 4,

                                SECOND_SNAKE_ROW        = 5,
                                SECOND_SNAKE_COLUMN     = 5,
                                SECOND_SNAKE_SIZE       = 4,

                                WINDOW_WIDTH            = 512,
                                WINDOW_HEIGHT           = 512;

    public static final boolean ENABLE_GRAPHICS         = true;

    static int[][] maze = new int[MAZE_ROW_NUM][MAZE_COLUMN_NUM];
    static Snake snake0 = new Snake( FIRST_SNAKE_ROW, FIRST_SNAKE_COLUMN, FIRST_SNAKE_SIZE );
    static Snake snake1 = new Snake( SECOND_SNAKE_ROW  , SECOND_SNAKE_COLUMN,SECOND_SNAKE_SIZE );
    // static final String logFile = "snakes/output.txt";

    // the game happens here
    public static void main(String[] args) throws InterruptedException {
        initializeMaze();
        if (ENABLE_GRAPHICS) {
            StdDraw.setCanvasSize(WINDOW_WIDTH, WINDOW_HEIGHT);
            StdDraw.clear(Color.WHITE);
        }
        Bot_g_andryushchenko bot = new Bot_g_andryushchenko();

        int turnNum = 0;
        // TODO Implement the stop criteria - DONE
        while( (snake0.alive && snake1.alive) && (!snake0.headCollision && !snake1.headCollision) ) {

            if ( turnNum%5 == 0 )
                divineGift();

            if (ENABLE_GRAPHICS)
                showMazeGraph();
            else
                showMaze();

            //appendMazeToFile(logFile);
            //Scanner scanner = new Scanner(System.in);
            //String inputString = scanner.nextLine();
            //String[] moves = inputString.split(" ");
            // TODO I need to check if moves[] has two positions - DONE
            // System.out.println(moves[0]); // snake 0
            String[] moves = new String[2];
            //moves[0] = snake0.nextMove();
            //moves[0] = bot.chooseDirection(snake0,snake1,maze);

            switch (bot.chooseDirection(snake0,snake1,maze)){
                case NORTH:
                    moves[0] = "N";
                    break;
                case EAST:
                    moves[0] = "E";
                    break;
                case SOUTH:
                    moves[0] = "S";
                    break;
                case WEST:
                    moves[0] = "W";
                    break;
            }

            boolean validMove0 = validateMove(moves[0], snake0, snake1);

            if ( validMove0 ) {
                if ( moves[0].equalsIgnoreCase("N") )
                    snake0.MoveN();
                if ( moves[0].equalsIgnoreCase("S") )
                    snake0.MoveS();
                if ( moves[0].equalsIgnoreCase("W") )
                    snake0.MoveW();
                if ( moves[0].equalsIgnoreCase("E") )
                    snake0.MoveE();
            }
            else {
                snake0.alive = false;
            }

            if (!ENABLE_GRAPHICS)
                System.out.println();

            //moves[1] = snake1.nextMove();
            switch (bot.chooseDirection(snake1,snake0,maze)){
                case NORTH:
                    moves[1] = "N";
                    break;
                case EAST:
                    moves[1] = "E";
                    break;
                case SOUTH:
                    moves[1] = "S";
                    break;
                case WEST:
                    moves[1] = "W";
                    break;
            }


            // System.out.println(moves[1]); // snake 1
            boolean validMove1 = validateMove(moves[1], snake1, snake0);
            // TODO update the position of the head of the snake 1 - DONE

            if ( validMove1 ) {
                if ( moves[1].equalsIgnoreCase("N") )
                    snake1.MoveN();
                if ( moves[1].equalsIgnoreCase("S") )
                    snake1.MoveS();
                if ( moves[1].equalsIgnoreCase("W") )
                    snake1.MoveW();
                if ( moves[1].equalsIgnoreCase("E") )
                    snake1.MoveE();
            }
            else {
                snake1.alive = false;
            }

            Thread.sleep(1000);

            // TODO Print and log the moves and an indicator if each was legal
            if ( !ENABLE_GRAPHICS ) {
                System.out.println();
                System.out.println(moves[0] + " " + moves[1]);
            }
            turnNum += 1;
            /*
             * For the future: when a snake takes an apple, the position of the apple
             * becomes the new head position.
             */
        }
        // TODO Print and log the result of the game (1-0, 0-0, 0-1) - DONE
        if ( snake0.headCollision || snake1.headCollision ) {
            if (ENABLE_GRAPHICS) {
                StdDraw.setPenColor(Color.black);
                StdDraw.text(0.5, 0.05, "Draw! : 0-0");
            } else
                System.out.println("0-0");
        }
        else if ( !snake1.alive ) {
            if (ENABLE_GRAPHICS) {
                StdDraw.setPenColor(Color.black);
                StdDraw.text(0.5, 0.05, "Yellow snake win! : 1-0");
            } else
                System.out.println("1-0");
        }
        else if ( !snake0.alive ) {
            if (ENABLE_GRAPHICS) {
                StdDraw.setPenColor(Color.black);
                StdDraw.text(0.5, 0.05, "Pink snake win! : 0-1");
            } else
                System.out.println("0-1");
        }
    }

    // we're checking if the snake can took a valid move
    private static boolean validateMove( String move, Snake snake, Snake anotherSnake ) {
        assert  move.equalsIgnoreCase("N" ) ||
                move.equalsIgnoreCase("S" ) ||
                move.equalsIgnoreCase("W" ) ||
                move.equalsIgnoreCase("E" ) : "The input (move) should be in {N, S, W, E}.";
        // TODO Add here rules about going off the board and colliding to another snake - DONE.

        // Validate North
        if  (   move.equalsIgnoreCase("N" ) &&
                (
                snake.getHead().row == 0  ||
                snake.belongsToSnake(snake.getHead().row-1,snake.getHead().column,false)
                )
            )
            return false;
        if  (   move.equalsIgnoreCase("N" ) &&
                anotherSnake.getHead().row == snake.getHead().row-1 &&
                anotherSnake.getHead().column == snake.getHead().column ) {
            snake.headCollision = true;
            return false;
        }
        if (    move.equalsIgnoreCase("N" ) &&
                anotherSnake.belongsToSnake(snake.getHead().row-1,snake.getHead().column) ) {
            return false;
        }


        // Validate South
        if  (   move.equalsIgnoreCase("S" ) &&
                (
                snake.getHead().row == MAZE_ROW_NUM - 1 ||
                snake.belongsToSnake(snake.getHead().row+1,snake.getHead().column,false)
                )
        )
            return false;
        if  (   move.equalsIgnoreCase("S" ) &&
                anotherSnake.getHead().row == snake.getHead().row+1 &&
                anotherSnake.getHead().column == snake.getHead().column ) {
            snake.headCollision = true;
            return false;
        }
        if  (   move.equalsIgnoreCase("S" ) &&
                anotherSnake.belongsToSnake(snake.getHead().row+1,snake.getHead().column) ) {
            return false;
        }

        // Validate West
        if  (   move.equalsIgnoreCase("W" ) &&
                (
                snake.getHead().column == 0 ||
                snake.belongsToSnake(snake.getHead().row,snake.getHead().column-1,false)
                )
            )
            return false;
        if  (   move.equalsIgnoreCase("W" ) &&
                anotherSnake.getHead().row == snake.getHead().row &&
                anotherSnake.getHead().column == snake.getHead().column-1 ) {
            snake.headCollision = true;
            return false;
        }
        if  (   move.equalsIgnoreCase("W" ) &&
                anotherSnake.belongsToSnake(snake.getHead().row,snake.getHead().column-1) ) {
            return false;
        }

        // Validate East
        if  (   move.equalsIgnoreCase("E" ) &&
                (
                snake.getHead().column == MAZE_COLUMN_NUM - 1 ||
                snake.belongsToSnake(snake.getHead().row,snake.getHead().column+1,false)
                )
            )
            return false;
        if  (   move.equalsIgnoreCase("E" ) &&
                anotherSnake.getHead().row == snake.getHead().row &&
                anotherSnake.getHead().column == snake.getHead().column+1 ) {
            snake.headCollision = true;
            return false;
        }
        if  (   move.equalsIgnoreCase("E" ) &&
                anotherSnake.belongsToSnake(snake.getHead().row,snake.getHead().column+1) ) {
            return false;
        }

        return true;
    }

    // renders the graphics
    private static void showMazeGraph() {
        for (int r = 0; r < maze.length; r++) {
            for (int c = 0; c < maze[r].length; c++) {
                double halfLength = 0.045;
                double offset = 0.15;
                double x = (double)c / 10 + offset;
                double y = (double)(maze.length-1) / 10 - (double)r / 10 + offset;

                if  ( snake0.getHead().row == r && snake0.getHead().column == c ) {
                    StdDraw.setPenColor(StdDraw.YELLOW);
                    StdDraw.filledSquare(x,y,halfLength);
                } else if ( snake1.getHead().row == r && snake1.getHead().column == c ) {
                    StdDraw.setPenColor(StdDraw.PINK);
                    StdDraw.filledSquare(x,y,halfLength);
                } else if (snake0.belongsToSnake(r,c)) {
                    StdDraw.setPenColor(StdDraw.PRINCETON_ORANGE);
                    StdDraw.filledSquare(x,y,halfLength);
                } else if (snake1.belongsToSnake(r,c)) {
                    StdDraw.setPenColor(StdDraw.MAGENTA);
                    StdDraw.filledSquare(x,y,halfLength);
                } else if ( maze[r][c] == 8 ) {
                    StdDraw.setPenColor(StdDraw.GREEN);
                    StdDraw.filledSquare(x,y,halfLength);
                    StdDraw.setPenColor(StdDraw.RED);
                    StdDraw.filledCircle(x,y,halfLength-0.01);
                } else {
                    StdDraw.setPenColor(StdDraw.GREEN);
                    StdDraw.filledSquare(x,y,halfLength);
                }
            }
        }
    }

    // prints the game in the console
    private static void showMaze() {
        for (int r = 0; r < maze.length; r++) {
            for (int c = 0; c < maze[r].length; c++) {
                if  (   (snake0.getHead().row == r && snake0.getHead().column == c) ||
                        (snake1.getHead().row == r && snake1.getHead().column == c)
                    )
                    System.out.print('@');
                else if (snake0.belongsToSnake(r,c))
                    System.out.print('0');
                else if (snake1.belongsToSnake(r,c))
                    System.out.print('1');
                else if ( maze[r][c] == 8 )
                    System.out.print('ò');
                else
                    System.out.print('.');

            }
            System.out.println();
        }
    }

    // generates an apple
    private static void divineGift() {
        int posRow, posColumn;
        // element of the maze which is equal to 8 is an apple
        do {
            posRow = (int) (MAZE_ROW_NUM * Math.random());
            posColumn = (int) (MAZE_COLUMN_NUM * Math.random());
        } while (
                    snake0.belongsToSnake(posRow,posColumn) ||
                    snake1.belongsToSnake(posRow,posColumn) ||
                            maze[posRow][posColumn] == 8
        );

        maze[posRow][posColumn] = 8;
    }

    // fill the maze in with zeros
    private static void initializeMaze() {
        for ( int i = 0 ; i < MAZE_ROW_NUM ; i++ ) {
            for ( int j = 0 ; j < MAZE_COLUMN_NUM ; j++ ) {
                maze[i][j] = 0;
            }
        }
    }

    /*private static void appendTextToFile(String file, String text) {
        // TODO To be implemented
    }*/

    /*private static void appendMazeToFile(String file) {
        try (FileWriter fw = new FileWriter(file, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            for (int r = 0; r < maze.length; r++) {
                for (int c = 0; c < maze[r].length; c++) {
                    Files.write(Paths.get(logFile), ".".getBytes(), StandardOpenOption.APPEND);
                }
                Files.write(Paths.get(logFile), "\n".getBytes(), StandardOpenOption.APPEND);
            }
        } catch (IOException e) {
            // TODO Exception handling left as an exercise
        }
    }*/

}





