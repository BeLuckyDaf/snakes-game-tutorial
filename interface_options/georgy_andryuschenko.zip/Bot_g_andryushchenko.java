package snakes;

import java.util.ArrayList;

public class Bot_g_andryushchenko implements Bot{

    // sorts three possible coordinates and returns the first one
    public Direction chooseDirection(Snake mySnake, Snake otherSnake, int[][] maze) {
        ArrayList<Integer> preCoords = new ArrayList<Integer>();
        for ( int i = 0 ; i < 4 ; i++ ) {
            int numOfCoord = (int) (4 * Math.random());
            while (preCoords.contains(numOfCoord)) {
                numOfCoord = (int) (4 * Math.random());
            }
                preCoords.add(numOfCoord);
        }

        ArrayList<Coordinate> coords = new ArrayList<Coordinate>();

        for ( int i = 0 ; i < 4 ; i++ ) {
            switch (preCoords.get(i)) {
                case 0:
                    coords.add(new Coordinate(mySnake.getHead().row - 1, mySnake.getHead().column));
                    break;
                case 1:
                    coords.add(new Coordinate(mySnake.getHead().row,mySnake.getHead().column+1));
                    break;
                case 2:
                    coords.add(new Coordinate(mySnake.getHead().row+1,mySnake.getHead().column));
                    break;
                case 3:
                    coords.add(new Coordinate(mySnake.getHead().row,mySnake.getHead().column-1));
                    break;
            }
        }

        for ( int i = 0 ; i < 3 ; i++ ) {
            for ( int j = 0 ; j < 3-i ; j++ ) {
                //System.out.println(coords.get(j).compareTo(coords.get(j+1)));
                if ( coords.get(j).compareTo(coords.get(j+1)) == -1 ) {
                    Coordinate t = coords.get(j+1);
                    coords.set(j+1,coords.get(j));
                    coords.set(j,t);
                }
            }
        }

        /*for ( int i = 0 ; i < 4 ; i++ ) {
            if ( coords.get(i).row == mySnake.getHead().row-1 && coords.get(i).column == mySnake.getHead().column )
                System.out.println(Direction.NORTH);
            if ( coords.get(i).row == mySnake.getHead().row && coords.get(i).column == mySnake.getHead().column+1 )
                System.out.println(Direction.EAST);
            if ( coords.get(i).row == mySnake.getHead().row+1 && coords.get(i).column == mySnake.getHead().column )
                System.out.println(Direction.SOUTH);
            else
                System.out.println(Direction.WEST);
        }*/

        if ( coords.get(0).row == mySnake.getHead().row-1 && coords.get(0).column == mySnake.getHead().column )
            return Direction.NORTH;
        if ( coords.get(0).row == mySnake.getHead().row && coords.get(0).column == mySnake.getHead().column+1 )
            return Direction.EAST;
        if ( coords.get(0).row == mySnake.getHead().row+1 && coords.get(0).column == mySnake.getHead().column )
            return Direction.SOUTH;
        else
            return Direction.WEST;
    }

}
