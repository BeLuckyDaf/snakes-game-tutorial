package snakes;

import java.util.ArrayList;
import java.util.Random;

public class Bot_l_morozova implements Bot{

    @Override
    public Direction chooseDirection(Snake mySnake, Snake otherSnake, int[][] maze) {
        ArrayList<Direction> v = new ArrayList<Direction>();
        v = mySnake.nextMove(otherSnake);
        return v.get(new Random().nextInt(v.size()));
    }
}
