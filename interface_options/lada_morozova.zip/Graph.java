package snakes;

import javax.swing.*;
import java.awt.*;

public class Graph extends JPanel {
    static final private int scale = 50;
    static final int x_offset = 40, y_offest = 5;

    private String score = "_-_";

    public void paintComponent(Graphics g) {
        g.setColor(new Color(0x9303a7));
        for (Position pos : Snakes.snake0.positions) {
            g.fillRect(x_offset + pos.column*scale, y_offest + pos.row*scale, scale, scale);
        }
        g.fillRect(195, 415, 20, 20);

        g.setColor(new Color(0xeadb4b));
        for (Position pos : Snakes.snake1.positions) {
            g.fillRect(x_offset + pos.column*scale, y_offest + pos.row*scale, scale, scale);
        }
        g.fillRect(265, 415, 20, 20);

        g.setColor(new Color(0xc87171));
        g.fillRect(x_offset+ Snakes.apple.column*scale, y_offest + Snakes.apple.row*scale, scale, scale);

        g.setColor(Color.WHITE);
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                g.drawRect(x_offset + i*scale, y_offest + j*scale, scale, scale);
            }
        }

        g.setFont(new Font("Arial", Font.PLAIN, 24));
        g.setColor(Color.WHITE);
        g.drawString(score, 222, 432);
    }

    public void setScore(String score) {
        this.score = score;
    }
}
