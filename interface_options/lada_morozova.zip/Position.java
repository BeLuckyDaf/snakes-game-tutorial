package snakes;

public class Position implements Comparable<Position>{
    int row;
    int column;

    public Position(int row, int column) {
        this.row = row;
        this.column = column;
    }
    @Override
    public int compareTo(Position o) {
        if (o.row==row && o.column == column){return 0;} else {
            if (o.row == row){
                if (o.column>column){return 1;} else {return -1;}
            }
        }
        if(o.row>row){return 1;}
        return -1;
    }
}
