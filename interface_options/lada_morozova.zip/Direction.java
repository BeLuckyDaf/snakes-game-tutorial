package snakes;

public enum Direction {
	NORTH, SOUTH, WEST, EAST, NONE;
}
