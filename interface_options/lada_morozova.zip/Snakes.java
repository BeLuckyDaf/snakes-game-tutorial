package snakes;
//l.morozova@innopolis.university
//Lada Morozova


import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Snakes {

	static int[][] maze = new int[8][8];
	static Snake snake0 = new Snake(2, 2);
	static Snake snake1 = new Snake(5, 5);
    static Position apple;


	public static void main(String[] args) throws InterruptedException {
	    createApple(snake1,snake0);
        Bot_l_morozova ret = new Bot_l_morozova();

		JFrame frame = new JFrame("Graphics");
		frame.setSize(500, 480);
		frame.setBackground(new Color(0x302d36));
		Graph graph = new Graph();
		frame.add(graph);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		TimeUnit.MILLISECONDS.sleep(1000);

		while (snake0.alive && snake1.alive) {
		    if (snake1.ateApple || snake0.ateApple){
		        createApple(snake1,snake0);
            }
			//showMaze();
			frame.repaint();
			System.out.println();
			Direction m0 = ret.chooseDirection(snake0, snake1,maze);
			if (m0 == Direction.NONE){snake0.headcollide(snake1);snake0.alive =false;} else{
			    if (!snake0.eatApple(m0,apple,snake1)){snake0.move(m0);}
				snake0.collide(snake1);
			}
			Direction m1 = ret.chooseDirection(snake1,snake0,maze);
			if (m1 == Direction.NONE){snake1.headcollide(snake0);snake1.alive=false;} else {
				if (!snake1.eatApple(m1,apple,snake0)){snake1.move(m1);}
				snake1.collide(snake0);
			}
			TimeUnit.MILLISECONDS.sleep(200);
			//System.out.println(m0+" "+m1);
		}
		if (!snake1.alive && !snake0.alive){
		    //System.out.println("0-0");
			graph.setScore("0-0");
        } else{
		    if (!snake0.alive){
		        //System.out.println("0-1");
				graph.setScore("0-1");
		    } else {
		        //System.out.println("1-0");
				graph.setScore("1-0");
            }
        }
		frame.repaint();
	}

    /**
     * Prints maze and snakes in it
     */
	/*private static void showMaze() {
		for (int r = 0; r < maze.length; r++) {
			for (int c = 0; c < maze[r].length; c++) {
			    if (r == apple.row && c == apple.column){System.out.print("@ ");} else{
				    if (snake0.getHead().row ==r && snake0.getHead().column == c){System.out.print("A ");} else{
					    if (snake0.contains(r,c)){System.out.print("a ");} else {
						    if (snake1.getHead().row ==r && snake1.getHead().column == c){System.out.print("B ");} else {
							    if (snake1.contains(r,c)){System.out.print("b ");} else {
								    System.out.print(". ");
							    }
						    }
					    }
				    }
			    }
			}
			System.out.println();
		}
	}*/


    /**
     * Determines the position of the apple in the maze
     * @param s1 snake 1
     * @param s2 snake 2
     */
    public static void createApple(Snake s1, Snake s2){
        ArrayList<Position> v = new ArrayList<Position>();
        for (int i =0; i<8; i++){
            for (int j = 0; j < 8; j++){
                if (!s1.contains(i,j) && !s2.contains(i,j)){
                    v.add(new Position(i,j));
                }
            }
        }
        apple = v.get(new Random().nextInt(v.size()));
    }
}



