package snakes;

import java.util.ArrayList;

public class Snake {
    boolean alive = true;
    boolean ateApple = false;
    ArrayList<Position> positions = new ArrayList<Position>();

    public Snake(int row, int column) {
        alive = true;
        this.positions.add(new Position(row,column));
        this.positions.add(new Position(row,column-1));
        this.positions.add(new Position(row,column-2));
    }



    /**
     * @return Returns head position
     */
    public Position getHead() {
        return positions.get(0);
    }


    /**
     * Moves the snake in the given direction
     * @param d Direction of movement
     */
    public void move(Direction d){
        prev();
        if (d == Direction.NORTH)
            this.getHead().row--;
        if (d == Direction.SOUTH)
            this.getHead().row++;
        if (d == Direction.WEST)
            this.getHead().column--;
        if (d == Direction.EAST)
            this.getHead().column++;

    }


    /**
     * @param r row of position
     * @param c column of position
     * @return Determines whether the coordinate belongs to a snake
     */
    public boolean contains(int r, int c){
        boolean flag =false;
        for (Position i: positions){
            if (i.row == r && i.column == c){flag = true;}
        }
        return flag;
    }


    /**
     * Moves the snake's body
     */
    public void prev(){
        for (int i = positions.size()-1; i>0; i--){
            positions.get(i).row= positions.get(i-1).row;
            positions.get(i).column = positions.get(i-1).column;
        }
    }


    /**
     * @param another another snake
     * @return list of possible moves
     */
    public ArrayList<Direction> nextMove(Snake another){
        ArrayList<Direction> v = new ArrayList<Direction>();
        //NORTH
        int r = this.getHead().row;
        int c = this.getHead().column;
        boolean flag = true;
        if (r==0){flag = false;} else{
            if (this.contains(r-1,c)){flag = false;} else{
                for (Position i:another.positions){
                    if (i.row == r-1 && i.column == c){flag = false;}
                }
            }
        }
        if (flag){v.add(Direction.NORTH);}
        //SOUTH
        flag = true;
        if (r==7){flag = false;} else{
            if (this.contains(r+1,c)){flag = false;} else{
                for (Position i:another.positions){
                    if (i.row == r+1 && i.column == c){flag = false;}
                }
            }

        }
        if (flag){v.add(Direction.SOUTH);}

        //WEST
        flag = true;
        if (c == 0){flag = false;} else{
            if (this.contains(r,c-1)){flag = false;} else {
                for (Position i:another.positions){
                    if (i.row == r && i.column == c-1){flag = false;}
                }
            }

        }
        if(flag){v.add(Direction.WEST);}
        //EAST
        flag = true;
        if (c == 7){flag = false;} else{
            if (this.contains(r,c+1)){flag = false;} else {
                for (Position i:another.positions){
                    if (i.row == r && i.column == c+1){flag = false;}
                }
            }
        }
        if (flag){v.add(Direction.EAST);}
        if (v.size() == 0){v.add(Direction.NONE);}
        return v;
    }


    /**
     * Сhecks if snake collide
     * @param another another snake
     */
    public void collide(Snake another){
        boolean flag = false;
        if (this.getHead().row == another.getHead().row && this.getHead().column == another.getHead().column){
            this.alive = false;
            another.alive = false;
        } else {
            if (another.contains(this.getHead().row, this.getHead().column)){
                this.alive = false;
            }
        }

    }


    /**
     * Checks if snakes collide head-to-head
     * @param another another snake
     */
    public void headcollide(Snake another){
        int r = this.getHead().row;
        int c = this.getHead().column;
        if (r!=0 && another.getHead().row==r-1 && another.getHead().column ==c){this.alive = false; another.alive = false;}
        if (r!=7 && another.getHead().row==r+1 && another.getHead().column ==c){this.alive = false; another.alive = false;}
        if (c!=0 && another.getHead().row==r && another.getHead().column ==c-1){this.alive = false; another.alive = false;}
        if (c!=7 && another.getHead().row==r && another.getHead().column ==c+1){this.alive = false; another.alive = false;}
    }


    /**
     * @param nm direction of next snake's move
     * @param apple position of apple
     * @param another another snake
     * @return if the apple eaten then true else false
     */
    public boolean eatApple(Direction nm, Position apple, Snake another){
        boolean flag = false;
        int r = this.getHead().row;
        int c = this.getHead().column;
        if (nm == Direction.NORTH&& apple.row == r-1 && apple.column == c){
            positions.add(0,apple);
            flag = true;
        }
        if (nm == Direction.SOUTH && apple.row == r+1 && apple.column == c){
            positions.add(0,apple);
            flag = true;
        }
        if (nm == Direction.WEST && apple.row == r && apple.column == c-1){
            positions.add(0,apple);
            flag = true;
        }
        if (nm == Direction.EAST && apple.row == r && apple.column == c+1){
            positions.add(0,apple);
            flag = true;
        }
        this.ateApple= flag;
        return flag;
    }
}